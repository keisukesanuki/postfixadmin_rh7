postfixadmin [![Build Status](https://travis-ci.org/postfixadmin/postfixadmin.svg?branch=postfixadmin_3.2)](https://travis-ci.org/postfixadmin/postfixadmin)
[![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/postfixadmin/Lobby)

============

PostfixAdmin - web based administration interface for Postfix mail servers


Useful Links
------------
 - [Probably all you need to read (pdf)](http://blog.cboltz.de/uploads/postfixadmin-30-english.pdf)
 - http://postfixadmin.sf.net - the current homepage for the project
 - [Docker Images](https://github.com/postfixadmin/docker)
 - [What is it? (txt)](/DOCUMENTS/POSTFIXADMIN.txt)
 - [Installation instructions](/INSTALL.TXT)
 - [Wiki](https://sourceforge.net/p/postfixadmin/wiki/)
 - [Mailing list](https://sourceforge.net/p/postfixadmin/discussion/676076)
 - [IRC channel](irc://irc.freenode.net/postfixadmin) (#postfixadmin on irc.freenode.net).
